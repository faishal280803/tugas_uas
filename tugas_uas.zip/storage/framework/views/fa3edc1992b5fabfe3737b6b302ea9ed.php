

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-start">
            <h6>List Cabang</h6>
            <button class="btn btn-success btn-sm">Tambah Cabang</button>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama Cabang</th>
                        <th>No Telp Cabang</th>
                        <th>Alamat Barang</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas_uas\resources\views/admin/cabang/index.blade.php ENDPATH**/ ?>